#!/usr/bin/perl -w

while(<>) {
    s/^(\d+) /0000 /g;
    print;
}
